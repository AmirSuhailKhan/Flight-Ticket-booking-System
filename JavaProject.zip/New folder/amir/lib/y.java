import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class y extends JFrame
{
Label l11=new Label("Search Your Flight");
Label l1=new Label("Source");
Label l2=new Label("Destination");
Label l3=new Label("Date");
TextField tf1=new TextField();
TextField tf2=new TextField();
TextField tf3=new TextField();
Button b1=new Button("Search");
y()
{
setVisible(true);
setSize(800,600);
setLayout(null);
setDefaultCloseOperation(EXIT_ON_CLOSE);
l11.setBounds(30,7,200,30);add(l11);

l1.setBounds(50,50,50,30);add(l1);
tf1.setBounds(110,50,150,30);add(tf1);
l2.setBounds(270,50,80,30);add(l2);
tf2.setBounds(360,50,150,30);add(tf2);
l3.setBounds(530,50,60,30);add(l3);
tf3.setBounds(590,50,150,30);add(tf3);
b1.setBounds(250,130,150,40);add(b1);
l11.setFont(l11.getFont().deriveFont(Font.BOLD, 20f));
l1.setFont(l1.getFont().deriveFont(Font.BOLD, 14f));
l2.setFont(l2.getFont().deriveFont(Font.BOLD, 14f));
l3.setFont(l3.getFont().deriveFont(Font.BOLD, 14f));
b1.setFont(b1.getFont().deriveFont(Font.BOLD, 20f));
b1.setBackground(Color.GREEN);

// b1.addActionListener(new ActionListener() {
//     @Override
//     public void actionPerformed(ActionEvent e)
//     {
//            SignUp s=new SignUp();
//            s.setVisible(true);
//            s.setBounds(200,200,500,300);
//     }
// });
}
public static void main(String args[])
{
new y();
}
}