import javax.swing.*;
import java.awt.*;
import java.text.NumberFormat;
import java.util.Date;
import java.io.*;
public class Airplane {
    private JFrame frame;
    private JPanel airPanel;
    private JTextField nameData;
    private JTextField sourceData;
    private JTextField destination;
    private JSpinner spinner1;
    private JTextArea boarding;
    private JLabel fare;

    public Airplane()
    {
        createGUI();
    }

    private void createGUI() {
        frame = new JFrame("Booking Page");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        airPanel = new JPanel();
        airPanel.setLayout(new GridLayout(7, 2, 10, 10));

        airPanel.add(new JLabel("Name: "));
        nameData = new JTextField(20);
        airPanel.add(nameData);

        airPanel.add(new JLabel("Source: "));
        sourceData = new JTextField(20);
        airPanel.add(sourceData);

        airPanel.add(new JLabel("Destination: "));
        destination = new JTextField(20);
        airPanel.add(destination);

        airPanel.add(new JLabel("Date of Journey: "));
        spinner1 = new JSpinner(new SpinnerDateModel());
        JSpinner.DateEditor editor = new JSpinner.DateEditor(spinner1, "dd/MM/yyyy");
        spinner1.setEditor(editor);
        airPanel.add(spinner1);

        airPanel.add(new JLabel("Boarding Time: "));
        boarding = new JTextArea(2, 20);
        airPanel.add(boarding);

        airPanel.add(new JLabel("Fare: "));
        fare = new JLabel("");
        airPanel.add(fare);

        JButton bookButton = new JButton("Book");
        JButton resetButton = new JButton("Reset");

        bookButton.addActionListener(e -> bookFlight());
        resetButton.addActionListener(e -> resetFields());

        JPanel buttonPanel = new JPanel();
        buttonPanel.add(bookButton);
        buttonPanel.add(resetButton);

        frame.getContentPane().add(airPanel, BorderLayout.CENTER);
        frame.getContentPane().add(buttonPanel, BorderLayout.SOUTH);

        frame.pack();
        frame.setVisible(true);
    }

    private void bookFlight() {
        Date date = (Date) spinner1.getValue();
        System.out.println("Booking flight for " + nameData.getText() +
                " from " + sourceData.getText() + " to " + destination.getText() +
                " on " + date.toString() + " at " + boarding.getText());
    
        // calculate fare based on flight details
        int fareAmount = 1000; // replace with actual fare calculation
    
        NumberFormat format = NumberFormat.getCurrencyInstance();
        fare.setText(format.format(fareAmount));
        
        // create a string to store the ticket details
        String ticketDetails = "Name: " + nameData.getText() + "\n"
                + "Source: " + sourceData.getText() + "\n"
                + "Destination: " + destination.getText() + "\n"
                + "Date of Journey: " + date.toString() + "\n"
                + "Boarding Time: " + boarding.getText() + "\n"
                + "Fare: " + format.format(fareAmount) + "\n\n";
    
        // write the ticket details to a file
        try {
            FileWriter writer = new FileWriter("booked_tickets.txt", true);
            writer.write(ticketDetails);
            writer.close();
            JOptionPane.showMessageDialog(frame, "Ticket booked successfully!");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(frame, "An error occurred while booking the ticket.");
            ex.printStackTrace();
        }
    }
    

    private void resetFields() {
        nameData.setText("");
        sourceData.setText("");
        destination.setText("");
        spinner1.setValue(new Date());
        boarding.setText("");
        fare.setText("");
    }

    public static void main(String[] args) {
        new Airplane();
    }
}
