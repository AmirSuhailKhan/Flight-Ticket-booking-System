import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;
class SignUp extends JFrame
{
    JTextField t1;
    JPasswordField t2;
    JButton b1;
    SignUp()
   { 
    setLayout(null);

    t1 = new JTextField(60);
    t2 = new  JPasswordField (60);
    b1 = new JButton("Submit");
    t1.setBounds (100,20,80,30);
    t2.setBounds (100,60,80,30);
    b1.setBounds (100, 100,80,30);
    add(t1);
    add(t2);
    add (b1);

    b1.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent ae)
        {
            try
            {
            FileWriter fw=new FileWriter("login.txt",true);
            fw.write(t1.getText()+"\t"+t2.getText()+"\n");
            fw.close();
            JFrame f =new JFrame();
            JOptionPane.showMessageDialog(f, "Registration completed");
            dispose();   
            }
            catch(Exception e)
            {}
        }
    });
    }
}
class Login extends JFrame{
    JTextField t1;
    JPasswordField t2;
    JButton b1,b2;
    Login(){
    setLayout(null); 
    setDefaultCloseOperation (EXIT_ON_CLOSE);
    t1 = new JTextField(60);
    t2 = new  JPasswordField (60);
    b1 = new JButton("Login");
    b2= new JButton("SignUp");
    JLabel l1=new JLabel("Name");
    Label l2=new Label("Password");
    l1.setBounds(50,60,40,30);
    l2.setBounds(50,100,60,30);
    t1.setBounds(150,60,120,30);
    t2.setBounds(150,100,120,30);
    b1.setBounds(170,150,80,30);
    b2.setBounds(170,180,80,30);
    Label l3=new Label("");
    l3.setBounds(300,80,200,30);
    b1.setBackground(Color.GREEN);
    b2.setBackground(Color.BLUE);
    add(l3);
    add(t1);
    add(t2);
    add(l1);
    add(l2);
    add(b1);
    add(b2);
    b1.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e) {
            boolean matched = false;
            String uname = t1.getText().toString();
            String pwd = t2.getText().toString();
            try {
                FileReader fr = new FileReader("login.txt");
                BufferedReader br = new BufferedReader(fr);
                String line;
                while ((line = br.readLine()) != null) {
                    if (line.equals(uname + "\t" + pwd)) {
                        matched = true;
                        break;
                    }
                }
                fr.close();
            } 
            catch (IOException e1) {
                e1.printStackTrace();
            }
          if(matched)
          {
            dispose();
            new Airplane();
          }
          else
          {
            l3.setText("Invalid Username or Password");
          }

        }

    });
    
    b2.addActionListener(new ActionListener() {
        @Override
        public void actionPerformed(ActionEvent e)
        {
               SignUp s=new SignUp();
               s.setVisible(true);
               s.setBounds(200,200,500,300);
        }
    });

    }
}
    class LoginDemo{
    public static void main(String[] args) {  
    Login l = new Login();
    l.setBounds (400, 200, 500, 300);
    l.setVisible(true);    
    }    
}